# Smile Adventure Database - ER Diagram Documentation

Generated on: 2025-06-11 11:55:15

## Database Information

- **Version**: PostgreSQL 15.13 (Debian 15.13-1.pgdg120+1) on x86_64-pc-linux-gnu, compiled by gcc (Debian 12.2.0-14) 12.2.0, 64-bit
- **Database Name**: smile_adventure
- **Schema Name**: public
- **Current User**: smileuser
- **Database Size**: 9485 kB

## Tables Overview

| Table Name | Type | Size | Description |
|------------|------|------|-------------|
| activities | BASE TABLE | 64 kB | No description |
| alembic_version | BASE TABLE | 24 kB | No description |
| assessments | BASE TABLE | 48 kB | No description |
| auth_user_sessions | BASE TABLE | 144 kB | No description |
| auth_users | BASE TABLE | 232 kB | No description |
| children | BASE TABLE | 168 kB | No description |
| game_sessions | BASE TABLE | 248 kB | No description |
| password_reset_tokens | BASE TABLE | 48 kB | No description |
| professional_profiles | BASE TABLE | 112 kB | No description |
| professional_reviews | BASE TABLE | 40 kB | No description |
| user_activity_logs | BASE TABLE | 40 kB | No description |
| user_preferences | BASE TABLE | 24 kB | No description |

## Table Structures

### activities

| Column | Type | Length | Nullable | Default | PK | FK | Description |
|--------|------|--------|----------|---------|----|----|-------------|
| id | integer | 32 | ✗ | nextval('activities_id_seq'::regclass) | ✓ |  |  |
| child_id | integer | 32 | ✗ |  |  | ✓ |  |
| activity_type | character varying | 50 | ✗ |  |  |  |  |
| activity_name | character varying | 200 | ✗ |  |  |  |  |
| description | text |  | ✓ |  |  |  |  |
| category | character varying | 50 | ✓ |  |  |  |  |
| points_earned | integer | 32 | ✗ |  |  |  |  |
| difficulty_level | integer | 32 | ✓ |  |  |  |  |
| started_at | timestamp with time zone |  | ✓ |  |  |  |  |
| completed_at | timestamp with time zone |  | ✗ | now() |  |  |  |
| duration_minutes | integer | 32 | ✓ |  |  |  |  |
| emotional_state_before | character varying | 50 | ✓ |  |  |  |  |
| emotional_state_after | character varying | 50 | ✓ |  |  |  |  |
| anxiety_level_before | integer | 32 | ✓ |  |  |  |  |
| anxiety_level_after | integer | 32 | ✓ |  |  |  |  |
| support_level_needed | character varying | 50 | ✓ |  |  |  |  |
| support_provided_by | character varying | 100 | ✓ |  |  |  |  |
| assistive_technology_used | json |  | ✗ |  |  |  |  |
| environment_type | character varying | 50 | ✓ |  |  |  |  |
| environmental_modifications | json |  | ✗ |  |  |  |  |
| sensory_accommodations | json |  | ✗ |  |  |  |  |
| completion_status | character varying | 50 | ✗ |  |  |  |  |
| success_rating | integer | 32 | ✓ |  |  |  |  |
| challenges_encountered | json |  | ✗ |  |  |  |  |
| strategies_used | json |  | ✗ |  |  |  |  |
| notes | text |  | ✓ |  |  |  |  |
| verified_by_parent | boolean |  | ✗ |  |  |  |  |
| verified_by_professional | boolean |  | ✗ |  |  |  |  |
| verification_notes | text |  | ✓ |  |  |  |  |
| created_at | timestamp with time zone |  | ✓ | now() |  |  |  |
| data_source | character varying | 50 | ✗ |  |  |  |  |

### alembic_version

| Column | Type | Length | Nullable | Default | PK | FK | Description |
|--------|------|--------|----------|---------|----|----|-------------|
| version_num | character varying | 32 | ✗ |  | ✓ |  |  |

### assessments

| Column | Type | Length | Nullable | Default | PK | FK | Description |
|--------|------|--------|----------|---------|----|----|-------------|
| id | integer | 32 | ✗ | nextval('assessments_id_seq'::regclass) | ✓ |  |  |
| child_id | integer | 32 | ✗ |  |  | ✓ |  |
| assessment_type | character varying | 100 | ✗ |  |  |  |  |
| assessment_name | character varying | 200 | ✗ |  |  |  |  |
| version | character varying | 50 | ✓ |  |  |  |  |
| administered_by | character varying | 200 | ✗ |  |  |  |  |
| administered_date | timestamp with time zone |  | ✗ |  |  |  |  |
| location | character varying | 200 | ✓ |  |  |  |  |
| raw_scores | json |  | ✓ |  |  |  |  |
| standard_scores | json |  | ✓ |  |  |  |  |
| percentiles | json |  | ✓ |  |  |  |  |
| age_equivalents | json |  | ✓ |  |  |  |  |
| interpretation | text |  | ✓ |  |  |  |  |
| recommendations | json |  | ✗ |  |  |  |  |
| goals_identified | json |  | ✗ |  |  |  |  |
| previous_assessment_id | integer | 32 | ✓ |  |  | ✓ |  |
| progress_summary | text |  | ✓ |  |  |  |  |
| areas_of_growth | json |  | ✗ |  |  |  |  |
| areas_of_concern | json |  | ✗ |  |  |  |  |
| status | character varying | 50 | ✗ |  |  |  |  |
| created_at | timestamp with time zone |  | ✓ | now() |  |  |  |
| updated_at | timestamp with time zone |  | ✓ |  |  |  |  |

### auth_user_sessions

| Column | Type | Length | Nullable | Default | PK | FK | Description |
|--------|------|--------|----------|---------|----|----|-------------|
| id | integer | 32 | ✗ | nextval('auth_user_sessions_id_seq'::regclass) | ✓ |  |  |
| user_id | integer | 32 | ✗ |  |  | ✓ |  |
| session_token | character varying | 255 | ✗ |  |  |  |  |
| refresh_token | character varying | 255 | ✓ |  |  |  |  |
| ip_address | character varying | 45 | ✓ |  |  |  |  |
| user_agent | text |  | ✓ |  |  |  |  |
| device_info | text |  | ✓ |  |  |  |  |
| location | character varying | 200 | ✓ |  |  |  |  |
| created_at | timestamp with time zone |  | ✗ | now() |  |  |  |
| last_accessed_at | timestamp with time zone |  | ✗ | now() |  |  |  |
| expires_at | timestamp with time zone |  | ✗ |  |  |  |  |
| is_active | boolean |  | ✗ |  |  |  |  |
| revoked_at | timestamp with time zone |  | ✓ |  |  |  |  |
| revoked_by | integer | 32 | ✓ |  |  |  |  |

### auth_users

| Column | Type | Length | Nullable | Default | PK | FK | Description |
|--------|------|--------|----------|---------|----|----|-------------|
| id | integer | 32 | ✗ | nextval('auth_users_id_seq'::regclass) | ✓ |  |  |
| email | character varying | 255 | ✗ |  |  |  |  |
| hashed_password | character varying | 255 | ✗ |  |  |  |  |
| first_name | character varying | 100 | ✗ |  |  |  |  |
| last_name | character varying | 100 | ✗ |  |  |  |  |
| full_name | character varying | 200 | ✓ |  |  |  |  |
| phone | character varying | 20 | ✓ |  |  |  |  |
| role | USER-DEFINED |  | ✗ |  |  |  |  |
| status | USER-DEFINED |  | ✗ |  |  |  |  |
| is_active | boolean |  | ✗ |  |  |  |  |
| is_verified | boolean |  | ✗ |  |  |  |  |
| email_verified_at | timestamp with time zone |  | ✓ |  |  |  |  |
| last_login_at | timestamp with time zone |  | ✓ |  |  |  |  |
| failed_login_attempts | integer | 32 | ✗ |  |  |  |  |
| locked_until | timestamp with time zone |  | ✓ |  |  |  |  |
| license_number | character varying | 100 | ✓ |  |  |  |  |
| specialization | character varying | 200 | ✓ |  |  |  |  |
| clinic_name | character varying | 200 | ✓ |  |  |  |  |
| clinic_address | text |  | ✓ |  |  |  |  |
| created_at | timestamp with time zone |  | ✗ | now() |  |  |  |
| updated_at | timestamp with time zone |  | ✓ |  |  |  |  |
| created_by | integer | 32 | ✓ |  |  |  |  |
| last_modified_by | integer | 32 | ✓ |  |  |  |  |
| timezone | character varying | 50 | ✗ |  |  |  |  |
| language | character varying | 10 | ✗ |  |  |  |  |
| avatar_url | character varying | 500 | ✓ |  |  |  |  |
| bio | text |  | ✓ |  |  |  |  |
| location | character varying | 100 | ✓ |  |  |  |  |
| emergency_contact_name | character varying | 100 | ✓ |  |  |  |  |
| emergency_contact_phone | character varying | 20 | ✓ |  |  |  |  |
| preferred_communication | character varying | 50 | ✓ |  |  |  |  |
| last_profile_update | timestamp with time zone |  | ✓ |  |  |  |  |

### children

| Column | Type | Length | Nullable | Default | PK | FK | Description |
|--------|------|--------|----------|---------|----|----|-------------|
| id | integer | 32 | ✗ | nextval('children_id_seq'::regclass) | ✓ |  |  |
| name | character varying | 100 | ✗ |  |  |  |  |
| age | integer | 32 | ✗ |  |  |  |  |
| date_of_birth | timestamp with time zone |  | ✓ |  |  |  |  |
| avatar_url | character varying | 500 | ✓ |  |  |  |  |
| parent_id | integer | 32 | ✗ |  |  | ✓ |  |
| points | integer | 32 | ✗ |  |  |  |  |
| level | integer | 32 | ✗ |  |  |  |  |
| achievements | json |  | ✗ |  |  |  |  |
| diagnosis | character varying | 200 | ✓ |  |  |  |  |
| support_level | integer | 32 | ✓ |  |  |  |  |
| diagnosis_date | timestamp with time zone |  | ✓ |  |  |  |  |
| diagnosing_professional | character varying | 200 | ✓ |  |  |  |  |
| sensory_profile | json |  | ✓ |  |  |  |  |
| behavioral_notes | text |  | ✓ |  |  |  |  |
| communication_style | character varying | 100 | ✓ |  |  |  |  |
| communication_notes | text |  | ✓ |  |  |  |  |
| current_therapies | json |  | ✗ |  |  |  |  |
| emergency_contacts | json |  | ✗ |  |  |  |  |
| safety_protocols | json |  | ✗ |  |  |  |  |
| baseline_assessment | json |  | ✓ |  |  |  |  |
| last_assessment_date | timestamp with time zone |  | ✓ |  |  |  |  |
| progress_notes | json |  | ✗ |  |  |  |  |
| is_active | boolean |  | ✓ |  |  |  |  |
| created_at | timestamp with time zone |  | ✗ | now() |  |  |  |
| updated_at | timestamp with time zone |  | ✓ |  |  |  |  |

### game_sessions

| Column | Type | Length | Nullable | Default | PK | FK | Description |
|--------|------|--------|----------|---------|----|----|-------------|
| id | integer | 32 | ✗ | nextval('game_sessions_id_seq'::regclass) | ✓ |  |  |
| child_id | integer | 32 | ✗ |  |  | ✓ |  |
| session_type | character varying | 50 | ✗ |  |  |  |  |
| scenario_name | character varying | 200 | ✗ |  |  |  |  |
| scenario_id | character varying | 100 | ✓ |  |  |  |  |
| started_at | timestamp with time zone |  | ✗ | now() |  |  |  |
| ended_at | timestamp with time zone |  | ✓ |  |  |  |  |
| duration_seconds | integer | 32 | ✓ |  |  |  |  |
| levels_completed | integer | 32 | ✗ |  |  |  |  |
| max_level_reached | integer | 32 | ✗ |  |  |  |  |
| score | integer | 32 | ✗ |  |  |  |  |
| interactions_count | integer | 32 | ✗ |  |  |  |  |
| correct_responses | integer | 32 | ✗ |  |  |  |  |
| help_requests | integer | 32 | ✗ |  |  |  |  |
| emotional_data | json |  | ✓ |  |  |  |  |
| interaction_patterns | json |  | ✓ |  |  |  |  |
| completion_status | character varying | 20 | ✗ |  |  |  |  |
| exit_reason | character varying | 100 | ✓ |  |  |  |  |
| achievement_unlocked | json |  | ✗ |  |  |  |  |
| parent_notes | text |  | ✓ |  |  |  |  |
| parent_rating | integer | 32 | ✓ |  |  |  |  |
| parent_observed_behavior | json |  | ✓ |  |  |  |  |
| device_type | character varying | 50 | ✓ |  |  |  |  |
| app_version | character varying | 20 | ✓ |  |  |  |  |
| session_data_quality | character varying | 20 | ✗ |  |  |  |  |
| scenario_version | character varying | 20 | ✓ |  |  |  |  |
| pause_count | integer | 32 | ✗ | 0 |  |  |  |
| total_pause_duration | integer | 32 | ✗ | 0 |  |  |  |
| incorrect_responses | integer | 32 | ✗ | 0 |  |  |  |
| hint_usage_count | integer | 32 | ✗ | 0 |  |  |  |
| achievements_unlocked | json |  | ✗ | '[]'::json |  |  |  |
| progress_markers_hit | json |  | ✗ | '[]'::json |  |  |  |
| device_model | character varying | 100 | ✓ |  |  |  |  |
| environment_type | character varying | 50 | ✓ |  |  |  |  |
| support_person_present | boolean |  | ✗ | false |  |  |  |
| ai_analysis | json |  | ✓ |  |  |  |  |
| created_at | timestamp with time zone |  | ✗ | now() |  |  |  |
| updated_at | timestamp with time zone |  | ✓ |  |  |  |  |

### password_reset_tokens

| Column | Type | Length | Nullable | Default | PK | FK | Description |
|--------|------|--------|----------|---------|----|----|-------------|
| id | integer | 32 | ✗ | nextval('password_reset_tokens_id_seq'::regclass) | ✓ |  |  |
| user_id | integer | 32 | ✗ |  |  | ✓ |  |
| token | character varying | 255 | ✗ |  |  |  |  |
| created_at | timestamp with time zone |  | ✗ | now() |  |  |  |
| expires_at | timestamp with time zone |  | ✗ |  |  |  |  |
| used_at | timestamp with time zone |  | ✓ |  |  |  |  |
| is_active | boolean |  | ✗ |  |  |  |  |

### professional_profiles

| Column | Type | Length | Nullable | Default | PK | FK | Description |
|--------|------|--------|----------|---------|----|----|-------------|
| id | integer | 32 | ✗ | nextval('professional_profiles_id_seq'::regclass) | ✓ |  |  |
| user_id | integer | 32 | ✗ |  |  | ✓ |  |
| license_type | character varying | 100 | ✓ |  |  |  |  |
| license_number | character varying | 100 | ✓ |  |  |  |  |
| license_state | character varying | 50 | ✓ |  |  |  |  |
| license_expiry | timestamp with time zone |  | ✓ |  |  |  |  |
| primary_specialty | character varying | 200 | ✓ |  |  |  |  |
| subspecialties | json |  | ✗ |  |  |  |  |
| certifications | json |  | ✗ |  |  |  |  |
| experience_years | integer | 32 | ✓ |  |  |  |  |
| clinic_name | character varying | 200 | ✓ |  |  |  |  |
| clinic_address | text |  | ✓ |  |  |  |  |
| clinic_phone | character varying | 20 | ✓ |  |  |  |  |
| practice_type | character varying | 100 | ✓ |  |  |  |  |
| asd_experience_years | integer | 32 | ✓ |  |  |  |  |
| asd_certifications | json |  | ✗ |  |  |  |  |
| preferred_age_groups | json |  | ✗ |  |  |  |  |
| treatment_approaches | json |  | ✗ |  |  |  |  |
| patient_count | integer | 32 | ✗ |  |  |  |  |
| average_rating | double precision | 53 | ✓ |  |  |  |  |
| total_sessions | integer | 32 | ✗ |  |  |  |  |
| available_days | json |  | ✗ |  |  |  |  |
| available_hours | json |  | ✓ |  |  |  |  |
| accepts_new_patients | boolean |  | ✗ |  |  |  |  |
| bio | text |  | ✓ |  |  |  |  |
| treatment_philosophy | text |  | ✓ |  |  |  |  |
| languages_spoken | json |  | ✗ |  |  |  |  |
| is_verified | boolean |  | ✗ |  |  |  |  |
| verified_at | timestamp with time zone |  | ✓ |  |  |  |  |
| verified_by | integer | 32 | ✓ |  |  |  |  |
| created_at | timestamp with time zone |  | ✗ | now() |  |  |  |
| updated_at | timestamp with time zone |  | ✓ |  |  |  |  |
| education | text |  | ✓ |  |  |  |  |
| availability | character varying | 50 | ✓ |  |  |  |  |
| accepts_insurance | boolean |  | ✗ | false |  |  |  |
| consultation_fee | numeric | 10 | ✓ |  |  |  |  |
| office_address | text |  | ✓ |  |  |  |  |
| online_consultation | boolean |  | ✗ | false |  |  |  |
| verification_date | timestamp with time zone |  | ✓ |  |  |  |  |

### professional_reviews

| Column | Type | Length | Nullable | Default | PK | FK | Description |
|--------|------|--------|----------|---------|----|----|-------------|
| id | integer | 32 | ✗ | nextval('professional_reviews_id_seq'::regclass) | ✓ |  |  |
| professional_id | integer | 32 | ✗ |  |  | ✓ |  |
| reviewer_id | integer | 32 | ✗ |  |  | ✓ |  |
| rating | integer | 32 | ✗ |  |  |  |  |
| review_text | text |  | ✓ |  |  |  |  |
| is_anonymous | boolean |  | ✗ | false |  |  |  |
| is_verified | boolean |  | ✗ | false |  |  |  |
| created_at | timestamp with time zone |  | ✗ | now() |  |  |  |
| updated_at | timestamp with time zone |  | ✗ | now() |  |  |  |

### user_activity_logs

| Column | Type | Length | Nullable | Default | PK | FK | Description |
|--------|------|--------|----------|---------|----|----|-------------|
| id | integer | 32 | ✗ | nextval('user_activity_logs_id_seq'::regclass) | ✓ |  |  |
| user_id | integer | 32 | ✗ |  |  | ✓ |  |
| activity_type | character varying | 50 | ✗ |  |  |  |  |
| activity_description | text |  | ✓ |  |  |  |  |
| ip_address | character varying | 45 | ✓ |  |  |  |  |
| user_agent | text |  | ✓ |  |  |  |  |
| timestamp | timestamp with time zone |  | ✗ | now() |  |  |  |

### user_preferences

| Column | Type | Length | Nullable | Default | PK | FK | Description |
|--------|------|--------|----------|---------|----|----|-------------|
| id | integer | 32 | ✗ | nextval('user_preferences_id_seq'::regclass) | ✓ |  |  |
| user_id | integer | 32 | ✗ |  |  | ✓ |  |
| language | character varying | 10 | ✗ | 'en'::character varying |  |  |  |
| timezone | character varying | 50 | ✗ | 'UTC'::character varying |  |  |  |
| notifications_enabled | boolean |  | ✗ | true |  |  |  |
| privacy_level | character varying | 20 | ✗ | 'standard'::character varying |  |  |  |
| theme | character varying | 20 | ✗ | 'light'::character varying |  |  |  |
| created_at | timestamp with time zone |  | ✗ | now() |  |  |  |
| updated_at | timestamp with time zone |  | ✗ | now() |  |  |  |

## Relationships

| From Table | From Column | To Table | To Column | Constraint | Update Rule | Delete Rule |
|------------|-------------|----------|-----------|------------|-------------|-------------|
| activities | child_id | children | id | fk_activities_child_id_children | NO ACTION | NO ACTION |
| assessments | child_id | children | id | fk_assessments_child_id_children | NO ACTION | NO ACTION |
| assessments | previous_assessment_id | assessments | id | fk_assessments_previous_assessment_id_assessments | NO ACTION | NO ACTION |
| auth_user_sessions | user_id | auth_users | id | fk_auth_user_sessions_user_id_auth_users | NO ACTION | CASCADE |
| children | parent_id | auth_users | id | fk_children_parent_id_auth_users | NO ACTION | NO ACTION |
| game_sessions | child_id | children | id | fk_game_sessions_child_id_children | NO ACTION | NO ACTION |
| password_reset_tokens | user_id | auth_users | id | fk_password_reset_tokens_user_id_auth_users | NO ACTION | CASCADE |
| professional_profiles | user_id | auth_users | id | fk_professional_profiles_user_id_auth_users | NO ACTION | NO ACTION |
| professional_reviews | professional_id | auth_users | id | fk_professional_reviews_professional_id_auth_users | NO ACTION | CASCADE |
| professional_reviews | reviewer_id | auth_users | id | fk_professional_reviews_reviewer_id_auth_users | NO ACTION | CASCADE |
| user_activity_logs | user_id | auth_users | id | fk_user_activity_logs_user_id_auth_users | NO ACTION | CASCADE |
| user_preferences | user_id | auth_users | id | fk_user_preferences_user_id_auth_users | NO ACTION | CASCADE |

## Cardinalities

Based on the foreign key relationships, here are the main cardinalities:

- **activities** to **children**: Many-to-One (N:1)
  - child_id → id
- **assessments** to **children**: Many-to-One (N:1)
  - child_id → id
- **assessments** to **assessments**: Many-to-One (N:1)
  - previous_assessment_id → id
- **auth_user_sessions** to **auth_users**: Many-to-One (N:1)
  - user_id → id
- **children** to **auth_users**: Many-to-One (N:1)
  - parent_id → id
- **game_sessions** to **children**: Many-to-One (N:1)
  - child_id → id
- **password_reset_tokens** to **auth_users**: Many-to-One (N:1)
  - user_id → id
- **professional_profiles** to **auth_users**: Many-to-One (N:1)
  - user_id → id
- **professional_reviews** to **auth_users**: Many-to-One (N:1)
  - professional_id → id
  - reviewer_id → id
- **user_activity_logs** to **auth_users**: Many-to-One (N:1)
  - user_id → id
- **user_preferences** to **auth_users**: Many-to-One (N:1)
  - user_id → id

## Enum Types

### userrole
Values: `PARENT`, `PROFESSIONAL`, `ADMIN`, `SUPER_ADMIN`

### userstatus
Values: `PENDING`, `ACTIVE`, `INACTIVE`, `SUSPENDED`, `DELETED`

